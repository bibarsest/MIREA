﻿#pragma once
#include <iostream>
using namespace std;

struct Session
{
    string subject = "#";
    string mark = "#";
};