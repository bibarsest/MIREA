﻿// Кузнецов Алексей, БАСО-04-22. Курсовая работа. Вариант 34.
// 08.05.2023

#include <iostream>
using namespace std;
#include <windows.h>
#include <fstream>
#include <sstream>
#include <string>
#include "Session.h"
#include "Functions_bib.h"
#include "Date_bib.h"
#include "Student_bib.h"
#include "StudentList_bib.h"
#include "Crypt_bib.h"

int main()
{
    SetConsoleCP(1251); 
    SetConsoleOutputCP(1251); 
    menu();
}
